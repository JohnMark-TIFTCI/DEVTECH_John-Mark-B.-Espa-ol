var number = 9;
if(number % 2 ===0){
console.log("the number is even");
}else{
    console.log("the number is odd");
}