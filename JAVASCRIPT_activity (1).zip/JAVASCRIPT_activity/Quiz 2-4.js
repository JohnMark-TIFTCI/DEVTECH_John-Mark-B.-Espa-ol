class Vehicle { 
    constructor( name, model, weight,color) {
        this.name = name;
        this.model = model;
        this.weight = weight;
        this.color = color;
    }
    displayDetails() {  
        console.log(`Name: ${this.name}`);
        console.log(`Model: ${this.model}`);
        console.log(`Weight: ${this.weight}`);
        console.log(`Color: ${this.color}`);
    }
}

class Car extends Vehicle { 
    constructor(name, model, weight, color) {  
        super(name, model, weight, color);  
    
    }
}

const vehicle = new Vehicle('honda', 'mobilio', '300kg', 'white');  

console.log('Vehicle Details:');
vehicle.displayDetails();

const car = new Car('toyota', 'fortuner', '400kg', 'blue');  

console.log('\nCar Details:');
car.displayDetails();
