class person{
    constructor(name, age, country, birthplace){
        this.name = name;
        this.age = age;
        this.country = country;
        this.birthplace = birthplace;
    }
    displayDetails() {
        console.log(`Name: ${this.name}`);
        console.log(`age: ${this.age}`);
        console.log(`country: ${this.country}`);
        console.log(`birthplace: ${this.birthplace}`);
    }
 }
 const persona1 = new Persona('rico galang', 25, 'australia', 'Manila');
 const persona2 = new Persona('Richard Topaz', 40, 'netherland', 'Sucat');
 const persona3 = new Persona('pia lim', 33, 'singapore', 'Rizal');
 const persona4 = new Persona('oichie abe', 33, 'switzerland', 'bicol');
 
 console.log('Persona-1 Details:');
 persona1.displayDetails();

 console.log('\nPersona-2 Details:');
 persona2.displayDetails();

 console.log('\nPersona-3 Details:');
 persona3.displayDetails();

 console.log('\nPersona-4 Details:');
 persona3.displayDetails();
