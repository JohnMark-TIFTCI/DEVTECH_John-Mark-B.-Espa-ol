var number = 99;
var number2 = 10;
if(number > number2){
console.log("num1 is greater");
}else{
    console.log("num2 greater");
}