var number = -99;
if(number > 0){
console.log("it is positive");
}else{
    console.log("it is negative");
}