class Person{
    constructor(name, age, country, birthplace){
        this.name = name;
        this.age = age;
        this.country = country;
        this.birthplace = birthplace;
    }
    displayDetails() {
        console.log(`Name: ${this.name}`);
        console.log(`age: ${this.age}`);
        console.log(`country: ${this.country}`);
        console.log(`birthplace: ${this.birthplace}`);
    }
 }
 const person1 = new Persona('rico galang', 25, 'australia', 'Manila');
 const person2 = new Person('Richard Topaz', 40, 'netherland', 'Sucat');
 const person3 = new Person('pia lim', 33, 'singapore', 'Rizal');
 const person4 = new Person('oichie abe', 33, 'switzerland', 'bicol');
 
 console.log('Persona-1 Details:');
 person1.displayDetails();

 console.log('\nPersona-2 Details:');
 person2.displayDetails();

 console.log('\nPersona-3 Details:');
 person3.displayDetails();

 console.log('\nPersona-4 Details:');
 person3.displayDetails();
