<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post Form</title>
</head>
<body>
    <h1>Post Form</h1>

    <form method="POST" action="submit_result.php"> 
        <label>My name is:</label>
        <input type="text" name="name" required><br>

        <label>My favorite movie is:</label>
        <input type="text" name="movie" required><br>

        <label>My degree is:</label>
        <select name="degree" required>
            <option value="Bachelor">Bachelor</option>
            <option value="Master">Master</option>
            <option value="PhD">PhD</option>
        </select><br>

        <label>Gender:</label>
        <div>
            <input type="radio" id="male" name="gender" value="Male" required>
            <label for="male">Male</label>

            <input type="radio" id="female" name="gender" value="Female" required>
            <label for="female">Female</label>
        </div><br>

        <label>My favorite unit(s):</label><br>
        <select name="units[]" multiple required>
            <option value="Poti">Poti</option>
            <option value="IP">IP</option>
            <option value="Networking">Networking</option>
        </select><br>

        <button type="submit">Submit</button>
    </form>
</body>
</html>
