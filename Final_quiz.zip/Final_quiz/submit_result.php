<?php

$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'user_data';

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $movie = htmlspecialchars($_POST['movie']);
    $degree = htmlspecialchars($_POST['degree']);
    $gender = htmlspecialchars($_POST['gender']);
    $units = $_POST['units'];
    $units_string = implode(", ", $units);

    
    $stmt = $conn->prepare("INSERT INTO user_information (name, movie, degree, gender, units) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $movie, $degree, $gender, $units_string);

    if ($stmt->execute()) {
        echo "<h2>Submission Successful</h2>";
        echo "<p><strong>My name is:</strong> $name</p>";
        echo "<p><strong>My favorite movie is:</strong> $movie</p>";
        echo "<p><strong>My degree is:</strong> $degree</p>";
        echo "<p><strong>My gender is:</strong> $gender</p>";
        echo "<p><strong>My favorite units are:</strong> $units_string</p>";
    } else {
        echo "<p style='color:red;'>Error: " . $stmt->error . "</p>";
    }

    $stmt->close();
}
?>
